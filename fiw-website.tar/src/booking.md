---
layout: base.njk
title: Booking
description: "fish is watching is available for live performances and collaborative sessions."
---

<section>
  <p>fish is watching is available for live performances and collaborative sessions.</p>
</section>

<section>
  <h2>What we do</h2>
  <div class="subsection">
    <p>Live improvised sessions in site-specific settings — private homes, galleries, studios, workshops, festivals. We bring modular setups and work with the acoustic character of the space. Every room shapes the sound differently.</p>
  </div>
</section>

<section>
  <h2>Format</h2>
  <div class="subsection">
    <p>Improvised session, recorded in a single take. No setlist, no rehearsal. Duration varies — typically 30 to 90 minutes, depending on the space and context.</p>
  </div>
</section>

<section>
  <h2>What we need</h2>
  <div class="subsection">
    <p>A space with its own character. Power. Some room to set up. We handle the rest.</p>
    <p>For technical details, see the <a href="/assets/fish-is-watching_TechRider.pdf" download>tech rider (PDF)</a>.</p>
  </div>
</section>

<section class="contact-section">
  <h2>Get in touch</h2>
  <div class="subsection">
    <p>For exhibitions and live performances: <a href="mailto:booking@fish-is-watching.com">booking@fish-is-watching.com</a></p>
    <p>For collaborations: <a href="mailto:hi@fish-is-watching.com">hi@fish-is-watching.com</a></p>
  </div>
</section>
