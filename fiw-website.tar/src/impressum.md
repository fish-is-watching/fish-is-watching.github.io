---
layout: base.njk
title: Impressum
description: "Legal notice for fish is watching."
---

<section>
  <h2>Responsible for content (§ 5 TMG)</h2>
  <div class="subsection">
    <p>Dmitrii Kremenskii</p>
    <p>Eberhardstrasse 37</p>
    <p>70038 Stuttgart, Germany</p>
    <p>Contact: <a href="mailto:hi@fish-is-watching.com">hi@fish-is-watching.com</a></p>
  </div>
</section>

<section>
  <h2>Liability for content</h2>
  <div class="subsection">
    <p>We carefully create all content on this website. However, we cannot guarantee that the information is complete, accurate, or up to date.</p>
  </div>
</section>

<section>
  <h2>Liability for external links</h2>
  <div class="subsection">
    <p>Our site contains links to external websites of third parties. We have no influence on the content of these sites and therefore cannot assume any liability for them.</p>
  </div>
</section>

<section>
  <h2>Copyright</h2>
  <div class="subsection">
    <p>All content on this website is protected by copyright. Any use beyond the limits of copyright law requires prior written permission.</p>
  </div>
</section>
