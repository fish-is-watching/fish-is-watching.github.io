---
layout: base.njk
title: Privacy Policy
description: "Privacy policy for fish is watching."
---

<section>
  <h2>General information</h2>
  <div class="subsection">
    <p>We respect your privacy and process personal data in accordance with the GDPR. This website collects as little personal data as possible. No user accounts, no contact forms, and no newsletter are used.</p>
  </div>
</section>

<section>
  <h2>Analytics</h2>
  <div class="subsection">
    <p>We use Simple Analytics, a privacy-friendly analytics service that does not track users, set cookies, or collect personally identifiable information.</p>
  </div>
</section>

<section>
  <h2>Embedded media</h2>
  <div class="subsection">
    <p>This site includes embedded content from YouTube, Bandcamp, and SoundCloud. When you load such content, the respective providers may collect data. Please refer to their privacy policies.</p>
  </div>
</section>

<section>
  <h2>Contact</h2>
  <div class="subsection">
    <p>For questions about this privacy policy: <a href="mailto:hi@fish-is-watching.com">hi@fish-is-watching.com</a></p>
  </div>
</section>
