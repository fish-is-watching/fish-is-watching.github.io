---
layout: base.njk
title: About
description: "fish is watching is a modular performance collective based in Stuttgart."
---

<section>
  <p>fish is watching is a modular performance collective based in Stuttgart. We work with sound as process — not as product.</p>
</section>

<section>
  <h2>What we do</h2>
  <div class="subsection">
    <p>The collective operates from a shared basement studio in the center of the city. We meet two to three times a week. What comes out of those meetings takes different forms — raw improvised sessions, edited tracks, composed pieces, ambient, techno, things that don't have a genre name yet.</p>
    <p>Some material stays as it was recorded. Some gets rearranged into something new. Some becomes part of a larger work. The starting point is always the same: people in a room with their instruments, no plan, no setlist. What happens after that depends on who was there and what the material asks for.</p>
  </div>
</section>

<section>
  <h2>How it works</h2>
  <div class="subsection">
    <p>The collective is modular. Each participant brings a specific setup and a specific way of listening. The combinations change. The sound changes with them.</p>
    <p>Sometimes it locks into a dense groove. Sometimes it drifts into texture. Sometimes it falls apart. All of this is material. The raw sessions document the process as it happened. The edited work reshapes it into something else. Both are valid outcomes of the same practice.</p>
    <p>We don't choose between improvisation and composition. We treat them as different stages of the same material finding its form.</p>
  </div>
</section>

<section>
  <h2>Who we are</h2>
  <div class="subsection">
    <p><span class="participant-name">Alen</span> — Modular synthesizer. Evolving textures and psychedelic, slow-building sound fields. A core member of the studio for over ten years.</p>
    <p><span class="participant-name">Chris</span> — Hardware synthesizers, drum machines, samplers. Twenty years of experience in sound — from stage and technical production to his own music projects. The longtime anchor of this studio.</p>
    <p><span class="participant-name">Dmitrii</span> — Software-based instruments, samplers, and self-built tools — from electromagnetic antennas to contact microphones and photoresistors.</p>
    <p class="secondary">The collective is open to other configurations. Other musicians have joined sessions with their own setups. The door is not closed.</p>
  </div>
</section>

<section>
  <h2>The studio</h2>
  <div class="subsection">
    <p>A basement in central Stuttgart. The group has been working there for about ten years. The space is not designed for performance — it's a working room. The acoustics are what they are. That's part of the sound.</p>
  </div>
</section>
